/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/tmp/mips64el-n32--glibc--stable/usr --sysconfdir=/tmp/mips64el-n32--glibc--stable/etc --enable-static --target=mips64el-buildroot-linux-gnu --with-sysroot=/tmp/mips64el-n32--glibc--stable/usr/mips64el-buildroot-linux-gnu/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/tmp/mips64el-n32--glibc--stable/usr --with-mpc=/tmp/mips64el-n32--glibc--stable/usr --with-mpfr=/tmp/mips64el-n32--glibc--stable/usr --with-pkgversion='Buildroot 2017.05' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --with-arch=mips64 --with-abi=n32 --enable-languages=c,c++ --with-build-time-tools=/tmp/mips64el-n32--glibc--stable/usr/mips64el-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "n32" }, { "arch", "mips64" }, { "llsc", "llsc" } };
